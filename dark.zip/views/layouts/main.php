<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    $seo = new \App\Libraries\SeoHelper($settings);
    echo $seo->render($page ?? null);
    echo $seo->gaScript();
    ?>
    <?php if (!empty($settings['favicon'])): ?>
    <link rel="icon" href="/<?= esc($settings['favicon']) ?>">
    <?php endif; ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"
          integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css"
          integrity="sha384-QuGBSgV5Im3DzL2z+8Ko9/hqNy/N0O7zwvXAtfd1MvPKWa/UbeLV65cfm4BV5Wgq" crossorigin="anonymous">
    <link rel="stylesheet" href="/css/tokens.css">
    <link rel="stylesheet" href="/themes/dark/css/style.css">
</head>
<body>

<a class="skip-link" href="#main-content">본문 바로가기</a>

<?= $this->include('components/navbar') ?>

<main id="main-content" tabindex="-1">
    <?php foreach (['success' => 'success', 'warning' => 'warning', 'error' => 'danger'] as $key => $cls): ?>
        <?php if (session()->has($key)): ?>
        <div class="dk-wrap py-2">
            <div class="alert alert-<?= $cls ?> alert-dismissible fade show mt-2" role="alert">
                <?= esc(session($key)) ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="알림 닫기"></button>
            </div>
        </div>
        <?php endif; ?>
    <?php endforeach; ?>

    <?php $isHome = (uri_string() === '' || uri_string() === '/'); ?>
    <?php if (!$isHome && !empty($subLeftBanners)): ?>
    <div class="dk-wrap dk-layout">
        <aside class="dk-sidebar">
            <?php foreach ($subLeftBanners as $b): ?>
            <div class="dk-banner-slot mb-3">
                <?php $alt = trim((string) ($b['alt_text'] ?? '')); ?>
                <?php if ($b['link_url']): ?>
                <a href="<?= esc($b['link_url']) ?>" target="<?= esc($b['link_target']) ?>"<?= $b['link_target'] === '_blank' ? ' rel="noopener"' : '' ?>>
                    <img src="/<?= esc($b['image_path']) ?>" alt="<?= esc($alt !== '' ? $alt : '배너') ?>" class="dk-banner-img">
                    <?php if ($b['link_target'] === '_blank'): ?><span class="visually-hidden">(새 창 열림)</span><?php endif; ?>
                </a>
                <?php else: ?>
                <img src="/<?= esc($b['image_path']) ?>" alt="<?= esc(trim((string) ($b['alt_text'] ?? ''))) ?>" class="dk-banner-img">
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
        </aside>
        <div class="dk-content">
            <?= $this->renderSection('content') ?>
        </div>
    </div>
    <?php else: ?>
    <?= $this->renderSection('content') ?>
    <?php endif; ?>
</main>

<?= $this->include('components/footer') ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" defer
        integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>
<script src="/themes/dark/js/main.js"></script>
<?= $this->renderSection('scripts') ?>
<?= $this->include('components/popups') ?>
<script src="/themes/default/js/popup.js"></script>
</body>
</html>
